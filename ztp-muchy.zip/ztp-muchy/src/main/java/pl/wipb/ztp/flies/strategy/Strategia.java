package pl.wipb.ztp.flies.strategy;

import java.awt.*;

public interface Strategia {
    void move(Mucha mucha);
    Color getColor();
}
