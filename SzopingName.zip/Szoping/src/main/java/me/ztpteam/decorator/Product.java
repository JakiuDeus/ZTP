package me.ztpteam.decorator;

public interface Product {
    void displayInfo();
}