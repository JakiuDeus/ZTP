package me.ztpteam.factory_method;

public class ExpressShipment implements Shipment {
    @Override
    public void deliver() {
        // TODO shipment implementation
    }
}
