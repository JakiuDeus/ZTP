package me.ztpteam.factory_method;

public interface Shipment {
    void deliver();
}
