package me.ztpteam.factory_method;

public class StandardShipment implements Shipment {
    @Override
    public void deliver() {
        // TODO shipment implementation
    }
}
