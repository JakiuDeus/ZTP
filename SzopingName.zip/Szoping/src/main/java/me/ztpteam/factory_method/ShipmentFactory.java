package me.ztpteam.factory_method;

public interface ShipmentFactory {
    Shipment createShipment();
}
