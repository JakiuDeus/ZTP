package me.ztpteam.strategy;

public interface ShippingCostStrategy {
    double calculateCost(double weight);
}
