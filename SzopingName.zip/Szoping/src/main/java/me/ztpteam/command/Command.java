package me.ztpteam.command;

public interface Command {
    void execute();
}
