package me.ztpteam.observer;

public interface ShipmentObserver {
    void update(String message);
}
