package me.ztpteam.adapter;

public interface PaymentGateway {
    void processPayment(double amount);
}
