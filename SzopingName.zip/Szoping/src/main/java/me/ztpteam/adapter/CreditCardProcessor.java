package me.ztpteam.adapter;

public class CreditCardProcessor {
    public void chargeCreditCard(double amount) {
        System.out.println("Charging credit card with amount: " + amount);
    }
}
